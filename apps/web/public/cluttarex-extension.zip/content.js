console.log("Cluttarex content script loaded");chrome.runtime.onMessage.addListener((e,r,o)=>(console.log("Cluttarex: Message received",e),e.action==="clean_page"?(f(e.font,e.theme,e.fontSize),o({success:!0})):e.action==="replace_content"&&(u(e.data,e.font,e.theme,e.fontSize),o({success:!0})),!0));function p(e){switch(e){case"serif":return'Georgia, Cambria, "Times New Roman", Times, serif';case"mono":return"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";case"slab":return'"Rockwell", "Roboto Slab", "Courier New", serif';case"dyslexic":return'"OpenDyslexic", "Comic Sans MS", "Verdana", sans-serif';case"sans":default:return'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif'}}function u(e,r="sans",o="light",a="20"){const c=p(r),t=o==="dark",s=t?"#000":"#fff",n=t?"#eee":"#111",i=t?"#333":"#eee",d=document.getElementById("cluttarex-overlay");d&&d.remove();const l=document.createElement("div");l.id="cluttarex-overlay",l.style.cssText=`
    all: initial;
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: ${s};
    color: ${n};
    z-index: 2147483647;
    overflow-y: auto;
    padding: 60px 20px;
    font-family: ${c};
    line-height: 1.6;
    display: block;
  `,l.innerHTML=`
    <style>
      #cluttarex-overlay * { 
        color: ${n} !important; 
        background-color: transparent !important;
      }
      #cluttarex-overlay h1 { font-size: 2.5em; margin-bottom: 30px; font-weight: 800; }
      #cluttarex-overlay .exit-btn {
        position: fixed; top: 20px; right: 20px; padding: 10px 20px; 
        background: ${t?"#333":"#eee"} !important; 
        color: ${n} !important; border: 1px solid ${i}; 
        cursor: pointer; font-weight: bold; font-family: sans-serif;
      }
    </style>
    <div style="all: revert; max-width: 750px; margin: 0 auto; display: block;">
      <button class="exit-btn" onclick="document.getElementById('cluttarex-overlay').remove()">EXIT</button>
      <h1 style="all: revert; display: block;">${e.title}</h1>
      <div style="all: revert; font-size: ${a}px; display: block;">${e.content}</div>
      <div style="all: revert; border-top: 1px solid ${i}; margin-top: 50px; padding-top: 20px; opacity: 0.3; font-size: 10px; font-weight: 900; letter-spacing: 2px; text-transform: uppercase; display: block;">
        End of Cluttarex Clean Version
      </div>
    </div>
  `,document.body.appendChild(l)}function f(e="sans",r="light",o="20"){var n;const a=((n=document.querySelector("h1"))==null?void 0:n.innerText)||document.title,t=(document.querySelector("article")||document.querySelector("main")||document.querySelector(".content")||document.body).cloneNode(!0);t.querySelectorAll("script, style, iframe, nav, footer, header, aside, .ad, .social, .comments, .sidebar").forEach(i=>i.remove()),u({title:a,content:t.innerHTML},e,r,o)}
