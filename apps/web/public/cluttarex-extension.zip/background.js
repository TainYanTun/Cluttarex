console.log("Cluttarex background service worker running");
